package com.speedforce.mod.client;

import com.mojang.blaze3d.platform.InputMappings;
import net.minecraft.client.settings.KeyBinding;
import net.minecraftforge.client.settings.KeyConflictContext;
import net.minecraftforge.fml.client.registry.ClientRegistry;
import org.lwjgl.glfw.GLFW;

public class KeyBindings {

    public static final String CATEGORY = "key.categories.speedforce";

    public static KeyBinding TOGGLE_SPEED;
    public static KeyBinding TIME_SLOW;
    public static KeyBinding TORNADO;
    public static KeyBinding LIGHTNING;
    public static KeyBinding RELIC;
    public static KeyBinding HOLOGRAM;
    public static KeyBinding BANISH;
    public static KeyBinding PHASE;

    public static void register() {
        TOGGLE_SPEED = create("key.speedforce.toggle_speed", GLFW.GLFW_KEY_V);
        TIME_SLOW    = create("key.speedforce.time_slow", GLFW.GLFW_KEY_R);
        TORNADO      = create("key.speedforce.tornado", GLFW.GLFW_KEY_T);
        LIGHTNING    = create("key.speedforce.lightning", GLFW.GLFW_KEY_G);
        RELIC        = create("key.speedforce.relic", GLFW.GLFW_KEY_H);
        HOLOGRAM     = create("key.speedforce.hologram", GLFW.GLFW_KEY_J);
        BANISH       = create("key.speedforce.banish", GLFW.GLFW_KEY_B);
        PHASE        = create("key.speedforce.phase", GLFW.GLFW_KEY_N);

        ClientRegistry.registerKeyBinding(TOGGLE_SPEED);
        ClientRegistry.registerKeyBinding(TIME_SLOW);
        ClientRegistry.registerKeyBinding(TORNADO);
        ClientRegistry.registerKeyBinding(LIGHTNING);
        ClientRegistry.registerKeyBinding(RELIC);
        ClientRegistry.registerKeyBinding(HOLOGRAM);
        ClientRegistry.registerKeyBinding(BANISH);
        ClientRegistry.registerKeyBinding(PHASE);
    }

    private static KeyBinding create(String name, int key) {
        return new KeyBinding(name, KeyConflictContext.IN_GAME, InputMappings.Type.KEYSYM, key, CATEGORY);
    }
}
