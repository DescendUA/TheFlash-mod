package com.speedforce.mod.client;

import com.speedforce.mod.ability.AbilityType;
import com.speedforce.mod.item.ModItems;
import com.speedforce.mod.network.NetworkHandler;
import com.speedforce.mod.network.PacketAbilityRequest;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.player.ClientPlayerEntity;
import net.minecraft.particles.RedstoneParticleData;
import net.minecraft.util.math.vector.Vector3f;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

import java.util.Random;

/**
 * Отвечает за: (1) чтение нажатых клавиш способностей и отправку пакетов,
 * (2) визуальные частицы молний вокруг игрока в костюме (чисто косметика,
 * не влияет на логику способностей).
 */
public class ClientEvents {

    private final Random random = new Random();

    // Флэш: оранжевые молнии с красным отливом
    private static final float[] FLASH_ORANGE = new float[]{1.0f, 0.55f, 0.0f};
    private static final float[] FLASH_RED_SHADOW = new float[]{0.8f, 0.05f, 0.05f};

    // Обратный Флэш: жёлтый костюм, красные молнии
    private static final float[] RFLASH_RED = new float[]{0.9f, 0.05f, 0.05f};
    private static final float[] RFLASH_RED_DARK = new float[]{0.55f, 0.0f, 0.0f};

    @SubscribeEvent
    public void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getInstance();
        ClientPlayerEntity player = mc.player;
        if (player == null) return;

        handleKeys();
        spawnSuitParticles(player);
    }

    private void handleKeys() {
        sendIfPressed(KeyBindings.TOGGLE_SPEED, AbilityType.TOGGLE_SPEED);
        sendIfPressed(KeyBindings.TIME_SLOW, AbilityType.TIME_SLOW);
        sendIfPressed(KeyBindings.TORNADO, AbilityType.TORNADO);
        sendIfPressed(KeyBindings.LIGHTNING, AbilityType.LIGHTNING);
        sendIfPressed(KeyBindings.RELIC, AbilityType.RELIC);
        sendIfPressed(KeyBindings.HOLOGRAM, AbilityType.HOLOGRAM);
        sendIfPressed(KeyBindings.BANISH, AbilityType.BANISH);
        sendIfPressed(KeyBindings.PHASE, AbilityType.PHASE);
    }

    private void sendIfPressed(net.minecraft.client.settings.KeyBinding key, AbilityType type) {
        while (key.isPressed()) {
            NetworkHandler.CHANNEL.sendToServer(new PacketAbilityRequest(type));
        }
    }

    private void spawnSuitParticles(ClientPlayerEntity player) {
        boolean flash = ModItems.wearingFlash(player);
        boolean reverse = ModItems.wearingReverseFlash(player);
        if (!flash && !reverse) return;
        // Частицы появляются активнее при спринте — визуализация "скоростной ауры"
        if (!player.isSprinting()) return;

        float[] c1 = flash ? FLASH_ORANGE : RFLASH_RED;
        float[] c2 = flash ? FLASH_RED_SHADOW : RFLASH_RED_DARK;

        for (int i = 0; i < 3; i++) {
            float[] c = random.nextBoolean() ? c1 : c2;
            double ox = (random.nextDouble() - 0.5) * player.getWidth() * 1.5;
            double oz = (random.nextDouble() - 0.5) * player.getWidth() * 1.5;
            double oy = random.nextDouble() * player.getHeight();
            player.world.addParticle(
                    new RedstoneParticleData(c[0], c[1], c[2], 1.2f),
                    player.getPosX() + ox, player.getPosY() + oy, player.getPosZ() + oz,
                    0.0, 0.01, 0.0);
        }
    }
}
