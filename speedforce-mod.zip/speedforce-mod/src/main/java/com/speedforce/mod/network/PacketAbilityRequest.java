package com.speedforce.mod.network;

import com.speedforce.mod.ability.AbilityExecutor;
import com.speedforce.mod.ability.AbilityType;
import net.minecraft.entity.player.ServerPlayerEntity;
import net.minecraft.network.PacketBuffer;
import net.minecraftforge.fml.network.NetworkEvent;

import java.util.function.Supplier;

public class PacketAbilityRequest {

    private final AbilityType type;

    public PacketAbilityRequest(AbilityType type) {
        this.type = type;
    }

    public static void encode(PacketAbilityRequest msg, PacketBuffer buf) {
        buf.writeEnumValue(msg.type);
    }

    public static PacketAbilityRequest decode(PacketBuffer buf) {
        return new PacketAbilityRequest(buf.readEnumValue(AbilityType.class));
    }

    public static void handle(PacketAbilityRequest msg, Supplier<NetworkEvent.Context> ctxSupplier) {
        NetworkEvent.Context ctx = ctxSupplier.get();
        ctx.enqueueWork(() -> {
            ServerPlayerEntity player = ctx.getSender();
            if (player != null) {
                AbilityExecutor.execute(player, msg.type);
            }
        });
        ctx.setPacketHandled(true);
    }
}
