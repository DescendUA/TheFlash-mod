package com.speedforce.mod.item;

import net.minecraft.item.crafting.Ingredient;
import net.minecraft.item.IArmorMaterial;
import net.minecraft.item.Items;
import net.minecraft.sound.SoundEvent;

import java.util.function.Supplier;

/**
 * Материалы брони. По прочности/защите близки к незеритовой броне,
 * так как костюм — не столько "защита", сколько источник способностей.
 */
public class ModArmorMaterials {

    // порядок значений защиты: [ботинки, штаны, нагрудник, шлем]
    public static final IArmorMaterial FLASH = new SpeedArmorMaterial(
            "flash", 37,
            new int[]{3, 6, 8, 3},
            15,
            () -> Ingredient.fromItems(Items.GOLD_INGOT)
    );

    public static final IArmorMaterial REVERSE_FLASH = new SpeedArmorMaterial(
            "reverse_flash", 37,
            new int[]{3, 6, 8, 3},
            15,
            () -> Ingredient.fromItems(Items.GOLD_INGOT)
    );

    /** Простая реализация IArmorMaterial без привязки к vanilla enum. */
    private static class SpeedArmorMaterial implements IArmorMaterial {
        private final String name;
        private final int durabilityMultiplier;
        private final int[] damageReduction;
        private final int enchantability;
        private final Supplier<Ingredient> repairMaterial;

        SpeedArmorMaterial(String name, int durabilityMultiplier, int[] damageReduction,
                            int enchantability, Supplier<Ingredient> repairMaterial) {
            this.name = name;
            this.durabilityMultiplier = durabilityMultiplier;
            this.damageReduction = damageReduction;
            this.enchantability = enchantability;
            this.repairMaterial = repairMaterial;
        }

        @Override
        public int getDurability(net.minecraft.inventory.EquipmentSlotType slotIn) {
            int[] base = new int[]{13, 15, 16, 11};
            return base[slotIn.getIndex()] * this.durabilityMultiplier;
        }

        @Override
        public int getDamageReductionAmount(net.minecraft.inventory.EquipmentSlotType slotIn) {
            return this.damageReduction[slotIn.getIndex()];
        }

        @Override
        public int getEnchantability() {
            return this.enchantability;
        }

        @Override
        public SoundEvent getSoundEvent() {
            return net.minecraft.util.SoundEvents.ITEM_ARMOR_EQUIP_GOLD;
        }

        @Override
        public Ingredient getRepairMaterial() {
            return this.repairMaterial.get();
        }

        @Override
        public String getName() {
            return "speedforce:" + this.name;
        }

        @Override
        public float getToughness() {
            return 2.0F;
        }

        @Override
        public float getKnockbackResistance() {
            return 0.0F;
        }
    }
}
