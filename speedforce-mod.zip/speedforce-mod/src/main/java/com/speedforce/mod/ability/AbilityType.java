package com.speedforce.mod.ability;

public enum AbilityType {
    TOGGLE_SPEED,   // переключить уровень скорости
    TIME_SLOW,      // замедление времени вокруг
    TORNADO,        // торнадо-руки
    LIGHTNING,      // бросок молнии
    RELIC,          // создать временный реликт
    HOLOGRAM,       // создать голограмму
    BANISH,         // изгнать цель в Спидфорс
    PHASE           // переключить прохождение сквозь блоки (только Reverse-Flash)
}
