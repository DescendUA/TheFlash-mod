package com.speedforce.mod.util;

import net.minecraft.util.math.vector.Vector3d;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Данные способностей игрока, живущие на сервере в памяти (без capability API,
 * чтобы упростить сборку). При желании можно перенести в полноценную Capability.
 */
public class SpeedForceData {

    private static final Map<UUID, SpeedForceData> DATA = new ConcurrentHashMap<>();

    public int speedTier = 1;          // 1..5, переключается клавишей
    public boolean phasing = false;    // только Обратный Флэш
    public boolean timeSlowActive = false;
    public long lastAbilityTick = 0;
    public long lastTimeSlowTick = -1000;
    public long lastTornadoTick = -1000;
    public long lastLightningTick = -1000;
    public long lastRelicTick = -1000;
    public long lastHologramTick = -1000;
    public long lastBanishTick = -1000;
    public long runningTicks = 0; // сколько тиков подряд бежит спринтом — влияет на "опыт" бега

    // для детекции бега по кругу (метание молнии заряжается пробежкой по кругу)
    public final Deque<Vector3d> recentPositions = new ArrayDeque<>();

    // изгнанные в Спидфорс сущности: id -> (позиция возврата, тик возврата)
    public static class Banished {
        public final UUID entityId;
        public final double x, y, z;
        public final long returnTick;
        public Banished(UUID entityId, double x, double y, double z, long returnTick) {
            this.entityId = entityId; this.x = x; this.y = y; this.z = z; this.returnTick = returnTick;
        }
    }

    public static SpeedForceData get(UUID playerId) {
        return DATA.computeIfAbsent(playerId, id -> new SpeedForceData());
    }

    public static void clear(UUID playerId) {
        DATA.remove(playerId);
    }

    public int maxTier() {
        return 5;
    }

    public void cycleTier() {
        speedTier = speedTier % maxTier() + 1;
    }
}
