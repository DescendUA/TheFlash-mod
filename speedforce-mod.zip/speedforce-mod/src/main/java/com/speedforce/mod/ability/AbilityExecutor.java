package com.speedforce.mod.ability;

import com.speedforce.mod.item.ModItems;
import com.speedforce.mod.util.SpeedForceData;
import net.minecraft.block.Blocks;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.item.ArmorStandEntity;
import net.minecraft.entity.player.ServerPlayerEntity;
import net.minecraft.inventory.EquipmentSlotType;
import net.minecraft.item.ItemStack;
import net.minecraft.potion.EffectInstance;
import net.minecraft.potion.Effects;
import net.minecraft.util.DamageSource;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.RayTraceContext;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.vector.Vector3d;
import net.minecraft.util.text.StringTextComponent;
import net.minecraft.world.World;
import net.minecraft.world.server.ServerWorld;

import java.util.List;

public class AbilityExecutor {

    private static final int TIME_SLOW_COOLDOWN = 15 * 20;
    private static final int TORNADO_COOLDOWN = 4 * 20;
    private static final int LIGHTNING_COOLDOWN = 6 * 20;
    private static final int RELIC_COOLDOWN = 10 * 20;
    private static final int HOLOGRAM_COOLDOWN = 20 * 20;
    private static final int BANISH_COOLDOWN = 25 * 20;

    public static void execute(ServerPlayerEntity player, AbilityType type) {
        if (!ModItems.wearingAnySpeedSuit(player)) {
            player.sendStatusMessage(new StringTextComponent("§cНужен полный костюм скоростной силы."), true);
            return;
        }
        SpeedForceData data = SpeedForceData.get(player.getUniqueID());
        long t = player.world.getGameTime();

        switch (type) {
            case TOGGLE_SPEED:
                data.cycleTier();
                player.sendStatusMessage(new StringTextComponent("§bУровень скорости: " + data.speedTier + "/" + data.maxTier()), true);
                break;
            case TIME_SLOW:
                if (cooldownReady(t, data.lastTimeSlowTick, TIME_SLOW_COOLDOWN, player, data)) {
                    data.lastTimeSlowTick = t;
                    timeSlow(player);
                }
                break;
            case TORNADO:
                if (cooldownReady(t, data.lastTornadoTick, TORNADO_COOLDOWN, player, data)) {
                    data.lastTornadoTick = t;
                    tornado(player);
                }
                break;
            case LIGHTNING:
                if (cooldownReady(t, data.lastLightningTick, LIGHTNING_COOLDOWN, player, data)) {
                    data.lastLightningTick = t;
                    lightningThrow(player, data);
                }
                break;
            case RELIC:
                if (cooldownReady(t, data.lastRelicTick, RELIC_COOLDOWN, player, data)) {
                    data.lastRelicTick = t;
                    createRelic(player);
                }
                break;
            case HOLOGRAM:
                if (cooldownReady(t, data.lastHologramTick, HOLOGRAM_COOLDOWN, player, data)) {
                    data.lastHologramTick = t;
                    createHologram(player);
                }
                break;
            case BANISH:
                if (cooldownReady(t, data.lastBanishTick, BANISH_COOLDOWN, player, data)) {
                    data.lastBanishTick = t;
                    banish(player);
                }
                break;
            case PHASE:
                if (ModItems.wearingReverseFlash(player)) {
                    data.phasing = !data.phasing;
                    player.noClip = data.phasing;
                    player.sendStatusMessage(new StringTextComponent(
                            data.phasing ? "§4Фаза: сквозь блоки." : "§7Фаза выключена."), true);
                } else {
                    player.sendStatusMessage(new StringTextComponent("§cТолько костюм Обратного Флэша умеет проходить сквозь блоки."), true);
                }
                break;
        }
    }

    private static boolean cooldownReady(long now, long last, int cooldown, ServerPlayerEntity player, SpeedForceData data) {
        if (now - last < cooldown) {
            int secLeft = (int) ((cooldown - (now - last)) / 20);
            player.sendStatusMessage(new StringTextComponent("§7Перезарядка: " + secLeft + "с"), true);
            return false;
        }
        return true;
    }

    // ---------------- Замедление времени ----------------
    private static void timeSlow(ServerPlayerEntity player) {
        double radius = 8.0;
        AxisAlignedBB box = player.getBoundingBox().grow(radius);
        List<LivingEntity> nearby = player.world.getEntitiesWithinAABB(LivingEntity.class, box,
                e -> e != player && e.isAlive());
        for (LivingEntity e : nearby) {
            e.addPotionEffect(new EffectInstance(Effects.SLOWNESS, 100, 6, false, true));
            e.addPotionEffect(new EffectInstance(Effects.MINING_FATIGUE, 100, 3, false, true));
            e.addPotionEffect(new EffectInstance(Effects.WEAKNESS, 100, 2, false, true));
        }
        // сам игрок при этом двигается как обычно (относительное ускорение)
        player.addPotionEffect(new EffectInstance(Effects.SPEED, 100, 2, false, true));
        player.sendStatusMessage(new StringTextComponent("§eВы замедлили время вокруг себя."), true);
    }

    // ---------------- Торнадо-руки ----------------
    private static void tornado(ServerPlayerEntity player) {
        Vector3d look = player.getLookVec();
        Vector3d center = player.getPositionVec().add(look.scale(2.0));
        AxisAlignedBB box = new AxisAlignedBB(center.x - 3, center.y - 2, center.z - 3,
                center.x + 3, center.y + 3, center.z + 3);
        List<LivingEntity> targets = player.world.getEntitiesWithinAABB(LivingEntity.class, box,
                e -> e != player && e.isAlive());
        for (LivingEntity e : targets) {
            e.attackEntityFrom(DamageSource.causePlayerDamage(player), 4.0f);
            Vector3d push = e.getPositionVec().subtract(player.getPositionVec()).normalize();
            e.setMotion(push.x * 1.4, 0.6, push.z * 1.4);
            e.velocityChanged = true;
        }
        // визуальный вихрь
        if (player.world instanceof ServerWorld) {
            ServerWorld sw = (ServerWorld) player.world;
            for (int i = 0; i < 40; i++) {
                double angle = (Math.PI * 2 / 40) * i;
                double r = 1.5;
                double px = center.x + Math.cos(angle) * r;
                double pz = center.z + Math.sin(angle) * r;
                sw.spawnParticle(net.minecraft.particles.ParticleTypes.CLOUD,
                        px, center.y, pz, 1, 0, 0.05, 0, 0.01);
            }
        }
        player.sendStatusMessage(new StringTextComponent("§bТорнадо-удар!"), true);
    }

    // ---------------- Бросок молнии ----------------
    private static void lightningThrow(ServerPlayerEntity player, SpeedForceData data) {
        RayTraceResult trace = player.pick(40.0, 0.0f, false);
        Vector3d target;
        if (trace.getType() == RayTraceResult.Type.BLOCK) {
            target = trace.getHitVec();
        } else {
            target = player.getPositionVec().add(player.getLookVec().scale(20));
        }
        if (player.world instanceof ServerWorld) {
            ServerWorld sw = (ServerWorld) player.world;
            net.minecraft.entity.effect.LightningBoltEntity bolt =
                    EntityType.LIGHTNING_BOLT.create(sw);
            if (bolt != null) {
                bolt.moveForced(target.x, target.y, target.z);
                bolt.setEffectOnly(false);
                sw.addEntity(bolt);
            }
        }
        player.sendStatusMessage(new StringTextComponent("§6Молния брошена!"), true);
    }

    // ---------------- Временный реликт ----------------
    private static void createRelic(ServerPlayerEntity player) {
        World world = player.world;
        RayTraceResult trace = player.pick(10.0, 0.0f, false);
        BlockPos pos;
        if (trace.getType() == RayTraceResult.Type.BLOCK) {
            pos = new BlockPos(trace.getHitVec()).up();
        } else {
            pos = player.getPosition();
        }
        net.minecraft.block.BlockState previous = world.getBlockState(pos);
        world.setBlockState(pos, Blocks.SEA_LANTERN.getDefaultState());
        if (world instanceof ServerWorld) {
            ServerWorld sw = (ServerWorld) world;
            sw.getServer().enqueue(new net.minecraft.util.concurrent.TickDelayedTask(
                    (int) world.getGameTime() + 30 * 20, () -> {
                        if (world.getBlockState(pos).getBlock() == Blocks.SEA_LANTERN) {
                            world.setBlockState(pos, previous);
                        }
                    }));
        }
        player.sendStatusMessage(new StringTextComponent("§dВременный реликт создан (исчезнет через 30с)."), true);
    }

    // ---------------- Голограмма ----------------
    private static void createHologram(ServerPlayerEntity player) {
        World world = player.world;
        ArmorStandEntity stand = new ArmorStandEntity(world, player.getPosX(), player.getPosY(), player.getPosZ());
        stand.rotationYaw = player.rotationYaw;
        stand.setInvisible(false);
        stand.setInvulnerable(true);
        stand.setNoGravity(true);
        stand.setSlot(EquipmentSlotType.HEAD, new ItemStack(ModItems.wearingReverseFlash(player)
                ? ModItems.REVERSE_FLASH_HELMET.get() : ModItems.FLASH_HELMET.get()));
        stand.setSlot(EquipmentSlotType.CHEST, new ItemStack(ModItems.wearingReverseFlash(player)
                ? ModItems.REVERSE_FLASH_CHESTPLATE.get() : ModItems.FLASH_CHESTPLATE.get()));
        stand.setSlot(EquipmentSlotType.LEGS, new ItemStack(ModItems.wearingReverseFlash(player)
                ? ModItems.REVERSE_FLASH_LEGGINGS.get() : ModItems.FLASH_LEGGINGS.get()));
        stand.setSlot(EquipmentSlotType.FEET, new ItemStack(ModItems.wearingReverseFlash(player)
                ? ModItems.REVERSE_FLASH_BOOTS.get() : ModItems.FLASH_BOOTS.get()));
        world.addEntity(stand);

        if (world instanceof ServerWorld) {
            ServerWorld sw = (ServerWorld) world;
            sw.getServer().enqueue(new net.minecraft.util.concurrent.TickDelayedTask(
                    (int) world.getGameTime() + 15 * 20, () -> {
                        if (stand.isAlive()) stand.remove();
                    }));
        }
        player.sendStatusMessage(new StringTextComponent("§fГолограмма создана (15с)."), true);
    }

    // ---------------- Изгнание в Спидфорс ----------------
    private static void banish(ServerPlayerEntity player) {
        Entity targetEntity = null;
        Vector3d eye = player.getEyePosition(1.0f);
        Vector3d reach = eye.add(player.getLookVec().scale(15));
        AxisAlignedBB search = new AxisAlignedBB(eye, reach).grow(1.0);
        List<LivingEntity> candidates = player.world.getEntitiesWithinAABB(LivingEntity.class, search,
                e -> e != player && e.isAlive());
        if (!candidates.isEmpty()) {
            targetEntity = candidates.get(0);
        }
        if (targetEntity == null) {
            player.sendStatusMessage(new StringTextComponent("§cНет цели для изгнания."), true);
            return;
        }
        LivingEntity target = (LivingEntity) targetEntity;
        double ox = target.getPosX(), oy = target.getPosY(), oz = target.getPosZ();
        // "Спидфорс" — симулируем далёкой точкой в мире (можно заменить на отдельный DimensionType)
        target.teleportKeepLoaded(target.getPosX(), 500, target.getPosZ());
        target.addPotionEffect(new EffectInstance(Effects.BLINDNESS, 15 * 20, 0, false, false));
        target.addPotionEffect(new EffectInstance(Effects.LEVITATION, 15 * 20, 0, false, false));

        if (player.world instanceof ServerWorld) {
            ServerWorld sw = (ServerWorld) player.world;
            LivingEntity finalTarget = target;
            sw.getServer().enqueue(new net.minecraft.util.concurrent.TickDelayedTask(
                    (int) player.world.getGameTime() + 15 * 20, () -> {
                        if (finalTarget.isAlive()) {
                            finalTarget.teleportKeepLoaded(ox, oy, oz);
                        }
                    }));
        }
        player.sendStatusMessage(new StringTextComponent("§4Цель изгнана в Спидфорс на 15с."), true);
    }
}
