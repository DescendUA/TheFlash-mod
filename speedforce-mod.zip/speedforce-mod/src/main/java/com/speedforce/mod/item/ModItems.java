package com.speedforce.mod.item;

import com.speedforce.mod.SpeedForceMod;
import net.minecraft.inventory.EquipmentSlotType;
import net.minecraft.item.ArmorItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroup;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModItems {

    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, SpeedForceMod.MODID);

    private static Item.Properties props() {
        return new Item.Properties().group(ItemGroup.COMBAT).maxStackSize(1);
    }

    // ---- Флэш ----
    public static final RegistryObject<Item> FLASH_HELMET = ITEMS.register("flash_helmet",
            () -> new ArmorItem(ModArmorMaterials.FLASH, EquipmentSlotType.HEAD, props()));
    public static final RegistryObject<Item> FLASH_CHESTPLATE = ITEMS.register("flash_chestplate",
            () -> new ArmorItem(ModArmorMaterials.FLASH, EquipmentSlotType.CHEST, props()));
    public static final RegistryObject<Item> FLASH_LEGGINGS = ITEMS.register("flash_leggings",
            () -> new ArmorItem(ModArmorMaterials.FLASH, EquipmentSlotType.LEGS, props()));
    public static final RegistryObject<Item> FLASH_BOOTS = ITEMS.register("flash_boots",
            () -> new ArmorItem(ModArmorMaterials.FLASH, EquipmentSlotType.FEET, props()));

    // ---- Обратный Флэш ----
    public static final RegistryObject<Item> REVERSE_FLASH_HELMET = ITEMS.register("reverse_flash_helmet",
            () -> new ArmorItem(ModArmorMaterials.REVERSE_FLASH, EquipmentSlotType.HEAD, props()));
    public static final RegistryObject<Item> REVERSE_FLASH_CHESTPLATE = ITEMS.register("reverse_flash_chestplate",
            () -> new ArmorItem(ModArmorMaterials.REVERSE_FLASH, EquipmentSlotType.CHEST, props()));
    public static final RegistryObject<Item> REVERSE_FLASH_LEGGINGS = ITEMS.register("reverse_flash_leggings",
            () -> new ArmorItem(ModArmorMaterials.REVERSE_FLASH, EquipmentSlotType.LEGS, props()));
    public static final RegistryObject<Item> REVERSE_FLASH_BOOTS = ITEMS.register("reverse_flash_boots",
            () -> new ArmorItem(ModArmorMaterials.REVERSE_FLASH, EquipmentSlotType.FEET, props()));

    /** Полный комплект Флэша надет? */
    public static boolean wearingFlash(net.minecraft.entity.LivingEntity e) {
        return e.getItemStackFromSlot(EquipmentSlotType.HEAD).getItem() == FLASH_HELMET.get()
                && e.getItemStackFromSlot(EquipmentSlotType.CHEST).getItem() == FLASH_CHESTPLATE.get()
                && e.getItemStackFromSlot(EquipmentSlotType.LEGS).getItem() == FLASH_LEGGINGS.get()
                && e.getItemStackFromSlot(EquipmentSlotType.FEET).getItem() == FLASH_BOOTS.get();
    }

    /** Полный комплект Обратного Флэша надет? */
    public static boolean wearingReverseFlash(net.minecraft.entity.LivingEntity e) {
        return e.getItemStackFromSlot(EquipmentSlotType.HEAD).getItem() == REVERSE_FLASH_HELMET.get()
                && e.getItemStackFromSlot(EquipmentSlotType.CHEST).getItem() == REVERSE_FLASH_CHESTPLATE.get()
                && e.getItemStackFromSlot(EquipmentSlotType.LEGS).getItem() == REVERSE_FLASH_LEGGINGS.get()
                && e.getItemStackFromSlot(EquipmentSlotType.FEET).getItem() == REVERSE_FLASH_BOOTS.get();
    }

    /** Надет любой из двух костюмов целиком (даёт базовые способности бега). */
    public static boolean wearingAnySpeedSuit(net.minecraft.entity.LivingEntity e) {
        return wearingFlash(e) || wearingReverseFlash(e);
    }
}
