package com.speedforce.mod.event;

import com.speedforce.mod.item.ModItems;
import com.speedforce.mod.util.SpeedForceData;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.ServerPlayerEntity;
import net.minecraft.potion.EffectInstance;
import net.minecraft.potion.Effects;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.vector.Vector3d;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingFallEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

/**
 * Пассивные способности, работающие каждый тик, пока надет костюм:
 * - уровень скорости растёт от бега и даёт эффект Speed
 * - бег по стенам: если игрок спринтует в стену и уровень скорости
 *   достаточно высокий, даём импульс вверх вместо остановки
 * - бег по воде: на высоком уровне скорости — движение по поверхности воды
 * - фаза (только Обратный Флэш): переключаемый noClip
 */
public class PlayerAbilityHandler {

    private static final int TICKS_PER_TIER_XP = 200; // сколько тиков спринта нужно, чтобы поднять "опыт"

    @SubscribeEvent
    public void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        if (!(event.player instanceof ServerPlayerEntity)) return;
        ServerPlayerEntity player = (ServerPlayerEntity) event.player;

        boolean flash = ModItems.wearingFlash(player);
        boolean reverse = ModItems.wearingReverseFlash(player);
        if (!flash && !reverse) return;

        SpeedForceData data = SpeedForceData.get(player.getUniqueID());

        tickSpeedLeveling(player, data);
        applySpeedEffect(player, data);
        tickWallRun(player, data);
        tickWaterRun(player, data);
        if (reverse) tickPhase(player, data);
        trackCirclePositions(player, data);
    }

    private void tickSpeedLeveling(ServerPlayerEntity player, SpeedForceData data) {
        if (player.isSprinting() && player.isOnGround()) {
            data.runningTicks++;
        }
    }

    private void applySpeedEffect(ServerPlayerEntity player, SpeedForceData data) {
        int amplifier = Math.max(0, data.speedTier - 1); // тир 1 = ваниль-спринт, тир 5 = Speed IV
        player.addPotionEffect(new EffectInstance(Effects.SPEED, 20, amplifier, false, false, true));
        if (data.speedTier >= 3) {
            // высокая скорость — постоянный тик регена как у "healing factor" спидстеров
            player.addPotionEffect(new EffectInstance(Effects.JUMP_BOOST, 20, 0, false, false, true));
        }
    }

    private void tickWallRun(ServerPlayerEntity player, SpeedForceData data) {
        if (data.speedTier < 3) return; // нужен опыт бега (тир 3+)
        if (!player.isSprinting()) return;
        boolean collidingHorizontally = player.collidedHorizontally;
        if (collidingHorizontally && !player.isOnGround()) {
            // бежим по стене: гасим вертикальное падение, даём небольшой подъём
            Vector3d motion = player.getMotion();
            double upward = 0.20 + 0.03 * (data.speedTier - 3);
            player.setMotion(motion.x, upward, motion.z);
            player.fallDistance = 0;
        } else if (collidingHorizontally && player.isOnGround()) {
            // разбег в стену на земле — тоже подкидывает вверх, чтобы "зацепиться" за стену
            Vector3d motion = player.getMotion();
            player.setMotion(motion.x, 0.35, motion.z);
        }
    }

    private void tickWaterRun(ServerPlayerEntity player, SpeedForceData data) {
        if (data.speedTier < 4) return; // нужен высокий опыт бега (тир 4+)
        if (!player.isInWater()) return;
        if (!player.isSprinting()) return;
        BlockPos below = player.getPosition().down();
        // если под игроком вода, "выталкиваем" его на поверхность и убираем сопротивление воды
        Vector3d motion = player.getMotion();
        player.setMotion(motion.x * 1.05, Math.max(motion.y, 0.08), motion.z * 1.05);
        player.setMotion(player.getMotion().mul(1.0, 1.0, 1.0));
        player.extinguish(); // на всякий случай снимаем горение при выходе на воду
    }

    private void tickPhase(ServerPlayerEntity player, SpeedForceData data) {
        // noClip выставляется/снимается через AbilityExecutor по нажатию клавиши PHASE.
        // Здесь только страхуем игрока: если он застрял в блоке после отключения фазы — поднимаем вверх.
        if (!data.phasing && player.noClip) {
            player.noClip = false;
        }
        if (data.phasing) {
            player.fallDistance = 0;
        }
    }

    private void trackCirclePositions(ServerPlayerEntity player, SpeedForceData data) {
        data.recentPositions.addLast(player.getPositionVec());
        while (data.recentPositions.size() > 40) {
            data.recentPositions.removeFirst();
        }
    }

    @SubscribeEvent
    public void onFall(LivingFallEvent event) {
        if (!(event.getEntity() instanceof ServerPlayerEntity)) return;
        ServerPlayerEntity player = (ServerPlayerEntity) event.getEntity();
        if (!ModItems.wearingAnySpeedSuit(player)) return;
        SpeedForceData data = SpeedForceData.get(player.getUniqueID());
        if (data.speedTier >= 3 || data.phasing) {
            event.setCanceled(true); // скоростная реакция гасит удар о землю
        } else if (data.speedTier == 2) {
            event.setDistance(event.getDistance() * 0.5f);
        }
    }
}
