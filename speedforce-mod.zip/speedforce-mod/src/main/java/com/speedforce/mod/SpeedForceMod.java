package com.speedforce.mod;

import com.speedforce.mod.client.ClientEvents;
import com.speedforce.mod.client.KeyBindings;
import com.speedforce.mod.event.PlayerAbilityHandler;
import com.speedforce.mod.item.ModItems;
import com.speedforce.mod.network.NetworkHandler;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.common.MinecraftForge;

/**
 * Speed Force: Flash & Reverse-Flash
 *
 * Полный комплект брони со способностями скоростной силы:
 * - Переключение уровня скорости (клавиша V по умолчанию)
 * - Бег по стенам и по воде (пассивно, зависит от уровня скорости)
 * - Замедление времени вокруг игрока
 * - Торнадо-руки (урон + отброс по конусу)
 * - Бросок молнии
 * - Временный реликт (блок, который исчезает через время)
 * - Голограмма (временная копия игрока)
 * - Изгнание цели в Спидфорс (телепорт с возвратом)
 * - Прохождение сквозь блоки (только Обратный Флэш)
 *
 * См. README.md для сборки под Forge 1.16.4.
 */
@Mod(SpeedForceMod.MODID)
public class SpeedForceMod {

    public static final String MODID = "speedforce";

    public SpeedForceMod() {
        IEventBus modEventBus = FMLJavaModLoadingContext.get().getModEventBus();

        ModItems.ITEMS.register(modEventBus);

        modEventBus.addListener(this::commonSetup);

        // Регистрация обработчиков на общей шине Forge
        MinecraftForge.EVENT_BUS.register(new PlayerAbilityHandler());

        // Клиентские классы регистрируем безопасно (только на клиенте)
        DistExecutor.safeRunWhenOn(net.minecraftforge.api.distmarker.Dist.CLIENT, () -> () -> {
            modEventBus.addListener(this::clientSetup);
            MinecraftForge.EVENT_BUS.register(new ClientEvents());
        });
    }

    private void commonSetup(final FMLCommonSetupEvent event) {
        event.enqueueWork(NetworkHandler::register);
    }

    private void clientSetup(final FMLClientSetupEvent event) {
        KeyBindings.register();
    }
}
